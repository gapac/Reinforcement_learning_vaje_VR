from circ_env.envs.circle_world import CircleEnvironment
from circ_env.envs.hockey_world import HockeyEnv